﻿namespace BudgetManager.Module.BusinessObjects.EnterpriseAnalyzerObjects
{
    public class Institution : FinacBaseObject
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string InstitutionType { get; set; }
    }
}
