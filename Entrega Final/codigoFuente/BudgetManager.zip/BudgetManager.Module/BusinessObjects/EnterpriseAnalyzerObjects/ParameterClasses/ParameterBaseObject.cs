﻿namespace BudgetManager.Module.BusinessObjects.EnterpriseAnalyzerObjects
{
    public class ParameterBaseObject
    {
    }
}
