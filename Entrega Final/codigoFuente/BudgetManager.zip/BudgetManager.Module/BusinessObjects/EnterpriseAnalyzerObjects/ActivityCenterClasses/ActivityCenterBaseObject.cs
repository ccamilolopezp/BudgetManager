﻿using DevExpress.Persistent.Base;

namespace BudgetManager.Module.BusinessObjects.EnterpriseAnalyzerObjects
{
    [NavigationItem("BaseObjects")]
    [DefaultClassOptions]
    public class ActivityCenterBaseObject : CompanyDataObject
    {

    }
}
