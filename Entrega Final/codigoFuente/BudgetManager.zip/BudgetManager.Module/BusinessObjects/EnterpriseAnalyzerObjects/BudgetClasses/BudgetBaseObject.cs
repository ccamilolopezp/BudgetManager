﻿namespace BudgetManager.Module.BusinessObjects.EnterpriseAnalyzerObjects
{
    public class BudgetBaseObject : CompanyDataObject
    {

    }
}
